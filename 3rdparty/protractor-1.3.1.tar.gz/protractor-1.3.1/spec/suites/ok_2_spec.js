describe('This test suite', function(){
  it('should be ran through the --suite option', function(){
    expect(true).toBe(true);
  });
});
